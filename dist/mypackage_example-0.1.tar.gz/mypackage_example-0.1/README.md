# mypackage
This library was created as an example of how to publish your own Python package

## building this package locally
'pyhton setup.py sdist'

## installing this package from GitHub
'pip install git+https://github.com/SLiKKSTaRR/mypackage_example.git'

## updating this package from GitHub
'pip install --upgrade git+https://github.com/SLiKKSTaRR/mypackage_example.git'